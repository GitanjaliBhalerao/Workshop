from flask import Flask,request,jsonify,send_file
app=Flask(__name__)

@app.route('/home')
def hello():
    return 'Hello Flask!'

@app.route('/about')
def about():
    return '<h1>this is web framework!<h1>'

if __name__=='__main__':
    app.run(debug=True)