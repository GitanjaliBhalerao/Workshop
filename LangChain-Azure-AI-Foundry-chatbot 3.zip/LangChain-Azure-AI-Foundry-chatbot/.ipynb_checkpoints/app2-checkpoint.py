# app.py
import os
import logging
from flask import Flask, request, jsonify, send_file
from dotenv import load_dotenv
from azure.core.credentials import AzureKeyCredential

from langchain_community.document_loaders import PyPDFLoader
#from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.text_splitters import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS

# ✅ NEW imports (replace RetrievalQA)
from langchain.chains import create_retrieval_chain
from langchain.chains.combine_documents import create_stuff_documents_chain

from langchain_core.prompts import ChatPromptTemplate
from langchain_core.messages import HumanMessage, SystemMessage

from langchain_azure_ai.embeddings import AzureAIEmbeddingsModel
from langchain_azure_ai.chat_models import AzureAIChatCompletionsModel

os.environ["KMP_DUPLICATE_LIB_OK"] = "TRUE"

# ─── Logging ─────────────────────────────────────────
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("rag_app")

# ─── Helpers ─────────────────────────────────────────

def load_and_split_pdf(pdf_path, chunk_size=1000, chunk_overlap=200):
    loader = PyPDFLoader(pdf_path)
    pages = loader.load()
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=chunk_size,
        chunk_overlap=chunk_overlap
    )
    return splitter.split_documents(pages)

def build_faiss_index(docs, embed_model, index_path="faiss_index"):
    if os.path.isdir(index_path):
        import shutil
        shutil.rmtree(index_path)

    vs = FAISS.from_documents(docs, embed_model)
    vs.save_local(index_path)
    return vs

# ✅ NEW chain builder
def create_rag_chain(vectorstore, chat_model, k=2):
    retriever = vectorstore.as_retriever(search_kwargs={"k": k})

    # Prompt template
    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a helpful assistant. Answer using the provided context."),
        ("human", "Context:\n{context}\n\nQuestion: {input}")
    ])

