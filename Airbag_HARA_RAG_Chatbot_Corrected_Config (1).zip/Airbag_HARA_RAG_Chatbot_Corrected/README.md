# Airbag HARA RAG Chatbot — Corrected Configuration Bundle

## Important credential security
The configuration screenshot included an Azure API key. Treat that key as exposed:
1. Revoke/rotate it in the Azure resource immediately.
2. Put the newly generated key in this folder's `.env` file locally.
3. Never upload `.env`, send it in chat, or commit it to source control.

The included `.env` has the endpoint and deployment labels transcribed from the screenshot, but the key is intentionally a placeholder. This is safer than redistributing an exposed secret.

## Configuration fixes
- Uses `AZURE_OPENAI_EMBEDDING_DEPLOYMENT` as the canonical embedding variable.
- Also accepts `AZURE_EMBED_MODEL` for compatibility with the name shown in the screenshot.
- Removes spaces around `=` and unnecessary quotes.
- Loads `.env` relative to `app.py`, not the current CMD folder.
- Uses `gpt-4.1-mini` for chat and `text-embedding-3-large` for embeddings as shown in the supplied configuration. Confirm these are the exact deployment names in your Azure AI Foundry resource.
- Rebuilds FAISS index at request time so it cannot silently reuse stale vectors.

## Windows CMD setup
Open CMD in this extracted folder:

```cmd
python -m venv .venv
.venv\Scripts\activate
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
```

Edit `.env`, replace `PASTE_NEW_KEY_HERE` with a newly rotated key, then run:

```cmd
python app.py
```

Open http://127.0.0.1:5000

## Quick checks
```cmd
python -c "from dotenv import load_dotenv; import os; from pathlib import Path; load_dotenv(Path('.env')); print('endpoint:', bool(os.getenv('AZURE_OPENAI_ENDPOINT'))); print('key:', bool(os.getenv('AZURE_OPENAI_API_KEY'))); print('chat:', bool(os.getenv('AZURE_OPENAI_CHAT_DEPLOYMENT')); print('embedding:', bool(os.getenv('AZURE_OPENAI_EMBEDDING_DEPLOYMENT')))"
```

Health endpoint: http://127.0.0.1:5000/health

## Example API request (CMD)
```cmd
curl -X POST http://127.0.0.1:5000/api/ask -H "Content-Type: application/json" -d "{\"question\":\"What function does the controller perform before issuing a deployment command?\",\"top_k\":4}"
```

## Troubleshooting
- `401`: rotate/check key and ensure it belongs to the endpoint's Azure resource.
- `404`: verify endpoint, API version, and exact deployment aliases in Azure AI Foundry.
- Embedding error: confirm the embedding deployment is actually deployed and its alias is correct.
- `ModuleNotFoundError`: activate `.venv` and rerun `python -m pip install -r requirements.txt`.
- Do not expose Flask beyond localhost or use this educational prototype for safety approval.

## Included
- `app.py`: corrected Flask + Azure OpenAI + FAISS chatbot
- `.env`: local settings with placeholder secret
- `.env.example`: safe configuration template
- `requirements.txt`
- `data/hara_retrieval_corpus.csv`: sample evidence corpus
- `outputs/`: generated FAISS index and metadata are created at runtime
