# Day 2 Airbag HARA Workshop Package — v1

Day 2 sequence:
1. 2.1 Functions and Malfunctions
2. 2.2 Cleaning and Versioning the Data
3. 2.3 Finding Things by Meaning
4. 2.4 Testing Whether a Prompt Is Good

Artifacts:
- Trainer guide
- Learner lab guide
- Four separate Jupyter notebooks
- Synthetic Airbag HARA input datasets
- Source documents
- Retrieval queries
- Prompt regression benchmark
- Outputs directory

Engineering principle:
Evidence -> provenance -> semantic retrieval -> measurable prompt evaluation.
