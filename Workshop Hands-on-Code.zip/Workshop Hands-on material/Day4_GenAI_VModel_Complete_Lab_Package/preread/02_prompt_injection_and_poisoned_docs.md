# Pre-read 2 — Prompt Injection and Poisoned Documents
## Prompt injection
Prompt injection attempts to influence the model through untrusted content. In a RAG system, retrieved documents can contain text that looks like instructions.

## Poisoned document
A poisoned document may contain false or adversarial content intended to manipulate the assistant. Treat retrieved content as evidence/data, not as authority.

## Defense in depth
- Explicit content labels
- Data/instruction separation
- Source allow-list
- Version/freshness checks
- Deterministic policy checks
- Schema validation
- Human approval
- Attack regression tests
- Audit logging

## Automotive relevance
Engineering systems often combine requirements, design documents, test reports, diagnostics and supplier material. Trust boundaries must be explicit. A document being retrievable does not make its instructions authoritative.
