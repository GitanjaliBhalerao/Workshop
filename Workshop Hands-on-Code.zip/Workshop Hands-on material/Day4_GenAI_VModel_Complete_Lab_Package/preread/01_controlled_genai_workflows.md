# Pre-read 1 — Controlled GenAI Workflows
## Why Day 4 matters
Day 3 established retrieval and grounding. Day 4 adds an execution contract: the assistant must operate through known states, with explicit checks and an accountable human gate.

## Six-state pattern
1. INTAKE — normalize and validate the request.
2. RETRIEVE — collect approved evidence.
3. DRAFT — produce a structured candidate.
4. VALIDATE — check schema, policy, evidence and security.
5. HUMAN_GATE — an accountable reviewer accepts, rejects or escalates.
6. PUBLISH — persist only an approved result.

A state machine reduces ambiguous control flow. The model can propose content; deterministic software decides whether the workflow may progress.

## One-repair rule
Allowing unlimited self-correction can create loops, latency and uncontrolled behavior. A practical training pattern is one repair attempt. If validation still fails, escalate.

## JSONL audit trail
One JSON object per line makes event streams easy to append, replay and inspect. Record metadata such as case ID, state, outcome, timestamp, versions and reason. Avoid logging secrets or unnecessary sensitive payloads.
