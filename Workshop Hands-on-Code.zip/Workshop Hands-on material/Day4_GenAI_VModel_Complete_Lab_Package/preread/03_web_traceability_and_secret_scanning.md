# Pre-read 3 — Traceable GenAI Web Applications
A production-oriented GenAI application needs more than a chat box.

## Minimum traceability
Every generated item should be tied to a case ID and evidence set. Citations should expose source ID and version. Stable paragraph/item IDs make reviews and test evidence easier.

## Secret scanning
Search for common secret patterns before publishing code or logs. This is a detection layer, not a guarantee that no secret exists.

## Production hardening beyond this lab
Authentication, RBAC, secure secret storage, CSRF protection, input limits, rate limiting, dependency scanning, TLS, secure headers, observability, retention controls and deployment approvals.
