# Pre-read 4 — Governance and Responsible Use
## Six risk-card questions
Purpose, users/accountability, data, failure modes, human oversight, and traceability/change.

## Change triggers
Reassessment should be triggered by material changes such as model version, prompt/control version, retrieval source/version, policy, data boundary, application release or safety impact.

## Safety-critical boundary
A GenAI assistant should not become the accountable engineering authority merely because it produces a confident answer. For safety-related workflows, define human ownership, approval criteria, evidence and escalation paths.

## Artifact manifest
A manifest links the application to its versions, owners, sources and controls. This creates an auditable snapshot for a release.
