import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ALLOWLIST = json.loads((ROOT/"config/allowlist.json").read_text())
ATTACK_MARKERS = [
    "ignore previous instructions",
    "reveal the system prompt",
    "bypass the reviewer",
    "approve automatically",
    "do not request human review",
]

def label_content(user_text, retrieved_text):
    """Make trust boundaries explicit: retrieved content is data, never workflow authority."""
    return {
        "system": "CONTROLLED_SYSTEM_INSTRUCTIONS",
        "user_data": user_text,
        "retrieved_data": retrieved_text,
    }

def is_source_allowed(source_id, version):
    return any(s["source_id"] == source_id and s["version"] == version for s in ALLOWLIST["sources"])

def detect_injection(text):
    t = text.lower()
    return [m for m in ATTACK_MARKERS if m in t]

def mandatory_disposition(text, source_id="D17-REQ", version="1.0", retrieved_text=""):
    """Return a deterministic training disposition before any model action."""
    reasons=[]
    if not is_source_allowed(source_id, version):
        reasons.append("source_not_allowlisted")
    reasons += [f"injection_marker:{x}" for x in detect_injection(text)]
    # Retrieved text is explicitly scanned as untrusted data.
    reasons += [f"retrieved_injection_marker:{x}" for x in detect_injection(retrieved_text)]
    if reasons:
        return {"disposition":"BLOCK","reasons":reasons}
    return {"disposition":"PASS","reasons":[]}
