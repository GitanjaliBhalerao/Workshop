import json, uuid, re
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ALLOWLIST = json.loads((ROOT/"config/allowlist.json").read_text())
PROMPT_VERSION = "L9"

def now():
    return datetime.now(timezone.utc).isoformat()

def log_event(event):
    path = ROOT / "logs" / "pipeline.jsonl"
    path.parent.mkdir(exist_ok=True)
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")

def source_allowed(source_id, version=None):
    for s in ALLOWLIST["sources"]:
        if s["source_id"] == source_id and (version is None or s["version"] == version):
            return True
    return False

@dataclass
class Context:
    case_id: str
    request: str
    sources: list
    draft: dict | None = None
    validation: dict | None = None
    disposition: str | None = None
    repair_count: int = 0

def intake(ctx):
    ok = bool(ctx.request.strip())
    outcome = "PASS" if ok else "BLOCK"
    log_event({"timestamp":now(),"case_id":ctx.case_id,"state":"INTAKE","outcome":outcome,"reason":"request_present" if ok else "empty_request","prompt_version":PROMPT_VERSION})
    return ok

def retrieve(ctx):
    # Deterministic training retrieval; in production this is the RAG layer.
    ctx.sources = [{"source_id":"D17-REQ","version":"1.0"}]
    ok = all(source_allowed(s["source_id"], s["version"]) for s in ctx.sources)
    log_event({"timestamp":now(),"case_id":ctx.case_id,"state":"RETRIEVE","outcome":"PASS" if ok else "BLOCK","reason":"allowlist_check","source_versions":ctx.sources,"prompt_version":PROMPT_VERSION})
    return ok

def draft(ctx):
    text = ctx.request.lower()
    injection = any(p in text for p in ["ignore previous", "reveal the system prompt", "bypass the reviewer", "approve automatically"])
    if injection:
        ctx.draft = {"answer":"I cannot bypass controls. The request requires controlled handling.","evidence":["D17-REQ:1.0"],"needs_human_gate":True}
    else:
        ctx.draft = {"answer":"Training summary generated from approved evidence.","evidence":["D17-REQ:1.0"],"needs_human_gate":True}
    log_event({"timestamp":now(),"case_id":ctx.case_id,"state":"DRAFT","outcome":"PASS","reason":"structured_candidate_created","source_versions":ctx.sources,"prompt_version":PROMPT_VERSION})
    return True

def validate(ctx):
    reasons=[]
    if not isinstance(ctx.draft, dict): reasons.append("draft_not_object")
    if not ctx.draft.get("answer"): reasons.append("answer_missing")
    if not ctx.draft.get("evidence"): reasons.append("evidence_missing")
    if not ctx.draft.get("needs_human_gate"): reasons.append("human_gate_missing")
    # Basic injection markers must not be accepted as an authority path.
    lower = ctx.request.lower()
    if any(p in lower for p in ["bypass the reviewer", "approve automatically"]):
        reasons.append("control_bypass_attempt")
    ok = not reasons
    ctx.validation = {"ok":ok,"reasons":reasons}
    log_event({"timestamp":now(),"case_id":ctx.case_id,"state":"VALIDATE","outcome":"PASS" if ok else "FAIL","reason":"schema_and_policy_check","prompt_version":PROMPT_VERSION})
    return ok

def human_gate(ctx, disposition="APPROVE"):
    # Training simulation: reviewer disposition is an explicit input.
    if disposition not in {"APPROVE","REJECT","ESCALATE"}:
        disposition="ESCALATE"
    ctx.disposition=disposition
    log_event({"timestamp":now(),"case_id":ctx.case_id,"state":"HUMAN_GATE","outcome":disposition,"reason":"explicit_human_disposition","prompt_version":PROMPT_VERSION})
    return disposition == "APPROVE"

def publish(ctx):
    if ctx.disposition != "APPROVE":
        log_event({"timestamp":now(),"case_id":ctx.case_id,"state":"PUBLISH","outcome":"BLOCK","reason":"no_approval","prompt_version":PROMPT_VERSION})
        return False
    log_event({"timestamp":now(),"case_id":ctx.case_id,"state":"PUBLISH","outcome":"PASS","reason":"approved_artifact_recorded","prompt_version":PROMPT_VERSION})
    return True

def run(request, human_disposition="APPROVE"):
    ctx=Context(str(uuid.uuid4()), request, [])
    if not intake(ctx): return ctx
    if not retrieve(ctx): return ctx
    draft(ctx)
    if not validate(ctx):
        ctx.repair_count += 1
        # Exactly one repair attempt.
        draft(ctx)
        if not validate(ctx):
            ctx.disposition="ESCALATE"
            human_gate(ctx,"ESCALATE")
            return ctx
    if not human_gate(ctx,human_disposition):
        return ctx
    publish(ctx)
    return ctx
