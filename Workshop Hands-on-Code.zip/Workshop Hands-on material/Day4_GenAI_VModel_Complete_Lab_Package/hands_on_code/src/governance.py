import json, re
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

SECRET_PATTERNS = [
    re.compile(r"(?i)api[_-]?key\s*[:=]\s*['\"][^'\"]+['\"]"),
    re.compile(r"(?i)password\s*[:=]\s*['\"][^'\"]+['\"]"),
    re.compile(r"sk-[A-Za-z0-9]{20,}"),
    re.compile(r"(?i)connectionstring\s*[:=]")
]

def scan_text(text):
    findings=[]
    for p in SECRET_PATTERNS:
        if p.search(text):
            findings.append(p.pattern)
    return findings

def scan_tree():
    findings=[]
    for path in ROOT.rglob("*"):
        if path.is_file() and ".git" not in path.parts and "logs" not in path.parts:
            try:
                text=path.read_text(encoding="utf-8")
            except Exception:
                continue
            hits=scan_text(text)
            if hits:
                findings.append({"file":str(path.relative_to(ROOT)),"patterns":hits})
    return findings

def risk_card():
    return {
        "purpose":"Training assistant for controlled engineering summarization",
        "users_and_accountability":"Learner/reviewer; human remains accountable",
        "data":"Approved training sources only",
        "failure_modes":["prompt injection","poisoned document","stale evidence","hallucination","schema failure"],
        "human_oversight":"Mandatory disposition before publish",
        "traceability_change":"Case ID, source version, prompt version and artifact manifest"
    }
