import json
from pathlib import Path
from src.controls import mandatory_disposition

ROOT=Path(__file__).resolve().parents[1]
poisoned=(ROOT/"data/poisoned_document.md").read_text()

for line in (ROOT/"data/d17_samples.jsonl").read_text().splitlines():
    case=json.loads(line)
    if case["attack_type"]=="source_bypass":
        result=mandatory_disposition(case["user_text"], "SUPPLIER-UNTRUSTED", "9.9")
    elif case["attack_type"]=="retrieved_instruction_attack":
        result=mandatory_disposition(case["user_text"], retrieved_text=poisoned)
    else:
        result=mandatory_disposition(case["user_text"])
    print(case["case_id"], case["attack_type"], "=>", result)

print("Poisoned document test =>",
      mandatory_disposition("Summarize the retrieved content.",
                            retrieved_text=poisoned))
