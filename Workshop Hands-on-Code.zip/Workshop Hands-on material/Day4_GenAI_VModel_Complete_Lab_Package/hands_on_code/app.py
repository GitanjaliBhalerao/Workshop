from flask import Flask, render_template, request, jsonify
from src.pipeline import run
from src.controls import mandatory_disposition
from src.governance import scan_tree, risk_card

app=Flask(__name__)

ITEMS=[
    {"id":"P-001","title":"Purpose","text":"Training assistant for controlled engineering summarization."},
    {"id":"P-002","title":"Human gate","text":"Safety-related outputs require explicit human disposition before publication."},
    {"id":"P-003","title":"Limitations","text":"Training simulation only; not a safety approval or vehicle release authority."},
]

@app.get("/")
def index(): return render_template("index.html", items=ITEMS)

@app.get("/generate")
def generate(): return render_template("generate.html")

@app.post("/generate")
def generate_post():
    text=request.form.get("request","")
    result=run(text, human_disposition="APPROVE")
    return render_template("report.html", result=result)

@app.get("/retrieve")
def retrieve():
    citations=[
        {"source_id":"D17-REQ","version":"1.0","citation":"Training requirement — controlled summary evidence."},
        {"source_id":"AIRBAG-TRAINING","version":"2026.09","citation":"Training assurance note — human disposition required."},
    ]
    return render_template("retrieve.html", citations=citations)

@app.get("/security")
def security():
    return jsonify({"secret_scan_findings":scan_tree()})

@app.get("/governance")
def governance():
    return render_template("governance.html", card=risk_card())

@app.get("/health")
def health(): return jsonify({"status":"ok","mode":"training"})

if __name__=="__main__":
    app.run(debug=False, host="127.0.0.1", port=5000)
