import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app import app

def test_home_and_generate_pages():
    client=app.test_client()
    assert client.get("/").status_code==200
    assert client.get("/generate").status_code==200

def test_security_endpoint():
    client=app.test_client()
    r=client.get("/security")
    assert r.status_code==200
    assert "secret_scan_findings" in r.get_json()
