# Day 4 — GenAI in V-Model System Development

This package operationalizes the Day 4 agenda shown in the supplied workshop plan.

## Package
- `learner/Day4_Learner_Lab_Guide.docx` — learner-facing guide
- `trainer/Day4_Trainer_Guide.docx` — facilitation guide + answer key
- `preread/` — four pre-read modules
- `hands_on_code/` — runnable Flask + pipeline + security + governance lab

## Run
```bash
cd hands_on_code
python -m venv .venv
# activate the environment
pip install -r requirements.txt
pytest -q
python app.py
```

Open `http://127.0.0.1:5000`.

## Safety boundary
The airbag examples are intentionally synthetic training scenarios. Nothing in this package is a validated automotive safety artifact or a production approval mechanism.
