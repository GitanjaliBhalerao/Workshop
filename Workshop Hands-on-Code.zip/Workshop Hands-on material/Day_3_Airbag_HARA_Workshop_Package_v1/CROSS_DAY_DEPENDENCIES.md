# Cross-Day Dependency Matrix

## Folder strategy

Keep the workshop as:

```text
Workshop Hands-on material/
├── Day_1_Airbag_HARA_Workshop_Package_v4/
├── Day_2_Airbag_HARA_Workshop_Package_v1/
└── Day_3_Airbag_HARA_Workshop_Package_v4_FINAL_CORRECTED/
```

### Manual copying required?

**No.** The corrected Day 3 package is designed to run independently from the Day 1 and Day 2 folders.

### Why?

The Day 3 notebooks need:
- a controlled retrieval corpus,
- retrieval queries,
- defective HARA samples,
- answer key,
- conflict cases,
- a classical ML baseline.

Those inputs are already present in the Day 3 package.

### Day 1 baseline

The agenda references a Day-1-style TF-IDF + Logistic Regression baseline. The Day 3 Topic 3.3 notebook preserves that concept but creates a reproducible controlled baseline and records Python/scikit-learn versions.

This avoids forcing learners to copy a pickle created in a different Python/scikit-learn environment.

### Day 2 retrieval

The Day 3 RAG exercise uses the Airbag HARA retrieval corpus and builds its own FAISS index. This keeps the Day 3 index reproducible and avoids dependency on a machine-specific Day 2 FAISS binary.

**Therefore: do not copy Day 2 `hazard_index.faiss` into Day 3.**

If a trainer wants to demonstrate artifact reuse explicitly, the Day 2 corpus can be compared with the Day 3 corpus, but this is an optional trainer activity rather than a prerequisite.
