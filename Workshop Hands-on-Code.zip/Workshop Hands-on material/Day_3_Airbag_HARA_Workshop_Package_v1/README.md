# Day 3 — Generating Candidates, Then Reviewing Them

Preferred infrastructure: Azure OpenAI Chat deployment + Azure OpenAI text-embedding-3-large + FAISS local vector index.

## Approved sequence
1. 3.1 Answering With Evidence (RAG)
2. 3.2 Spotting the Planted Defects / The Independent Reviewer
3. 3.3 Choosing the Right Method for Each Job
4. 3.4 Measuring the Generator and the Reviewer

## Run order
Run notebooks in numerical order. Day 3 reuses the Day 2 corpus and FAISS index. If `hazard_index.faiss` is not present, Topic 3.1 can build it using the Azure embedding deployment.

## Azure setup
Set `AZURE_OPENAI_ENDPOINT`, `AZURE_OPENAI_API_KEY`, `AZURE_OPENAI_API_VERSION`, `AZURE_OPENAI_CHAT_DEPLOYMENT`, and `AZURE_OPENAI_EMBEDDING_DEPLOYMENT`. The embedding deployment should be `text-embedding-3-large` or the deployment name mapped to that model.

## Governance
Do not put secrets in notebooks. Do not treat model output as final safety approval. Every generated candidate is an engineering artifact requiring review and traceability.
