import os
import json
from pathlib import Path

import numpy as np
import pandas as pd
import faiss
from openai import AzureOpenAI


REQUIRED_AZURE_VARS = [
    "AZURE_OPENAI_ENDPOINT",
    "AZURE_OPENAI_API_KEY",
    "AZURE_OPENAI_API_VERSION",
    "AZURE_OPENAI_CHAT_DEPLOYMENT",
    "AZURE_OPENAI_EMBEDDING_DEPLOYMENT",
]


def validate_azure_config():
    """Fail fast. Never silently substitute a model name for a deployment name."""
    missing = [name for name in REQUIRED_AZURE_VARS if not os.getenv(name)]
    if missing:
        raise RuntimeError(
            "Missing Azure OpenAI configuration:\n"
            + "\n".join(f"  - {name}" for name in missing)
            + "\n\nCheck azure.env and make sure the deployment names are populated."
        )

    print("Azure configuration: OK")
    print("Chat deployment:", os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT"])
    print("Embedding deployment:", os.environ["AZURE_OPENAI_EMBEDDING_DEPLOYMENT"])
    print(
        "Embedding deployment must point to the Azure deployment whose underlying "
        "model is text-embedding-3-large."
    )


def get_embedding_deployment():
    value = os.getenv("AZURE_OPENAI_EMBEDDING_DEPLOYMENT")
    if not value:
        raise RuntimeError(
            "AZURE_OPENAI_EMBEDDING_DEPLOYMENT is not set. "
            "Do not use text-embedding-3-large as a fallback model name; "
            "use the actual Azure deployment name."
        )
    return value


def get_chat_deployment():
    value = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT")
    if not value:
        raise RuntimeError(
            "AZURE_OPENAI_CHAT_DEPLOYMENT is not set. "
            "Use the actual Azure chat deployment name."
        )
    return value


def get_client():
    validate_azure_config()
    return AzureOpenAI(
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
        api_version=os.environ["AZURE_OPENAI_API_VERSION"],
    )


def test_embedding(client=None):
    """Make one small Azure embedding call before building FAISS."""
    client = client or get_client()
    deployment = get_embedding_deployment()
    response = client.embeddings.create(
        model=deployment,
        input=["Airbag unintended deployment can cause occupant injury."]
    )
    vector = response.data[0].embedding
    print("Embedding preflight: SUCCESS")
    print("Embedding deployment:", deployment)
    print("Returned vector dimensions:", len(vector))
    return vector


def embed_texts(texts, client=None, deployment=None, batch_size=16):
    client = client or get_client()
    deployment = deployment or get_embedding_deployment()

    if not deployment:
        raise RuntimeError("Embedding deployment is empty.")

    out = []
    for i in range(0, len(texts), batch_size):
        resp = client.embeddings.create(
            model=deployment,
            input=list(texts[i:i + batch_size])
        )
        out.extend([d.embedding for d in resp.data])

    arr = np.asarray(out, dtype="float32")
    faiss.normalize_L2(arr)
    return arr


def build_index(corpus_csv, index_path, metadata_path, client=None):
    client = client or get_client()

    df = pd.read_csv(corpus_csv).fillna("")
    required_columns = [
        "document_id", "version", "section", "paragraph", "content"
    ]
    missing = [c for c in required_columns if c not in df.columns]
    if missing:
        raise ValueError(
            "Corpus is missing required columns: " + ", ".join(missing)
        )

    texts = (
        df["document_id"].astype(str)
        + " | v" + df["version"].astype(str)
        + " | " + df["section"].astype(str)
        + " | " + df["paragraph"].astype(str)
        + " | " + df["content"].astype(str)
    ).tolist()

    emb = embed_texts(texts, client=client)
    index = faiss.IndexFlatIP(emb.shape[1])
    index.add(emb)

    Path(index_path).parent.mkdir(parents=True, exist_ok=True)
    Path(metadata_path).parent.mkdir(parents=True, exist_ok=True)

    faiss.write_index(index, str(index_path))
    df.to_json(metadata_path, orient="records", indent=2)

    return index, df


def load_index(index_path, metadata_path):
    if not Path(index_path).exists():
        raise FileNotFoundError(f"FAISS index not found: {index_path}")
    if not Path(metadata_path).exists():
        raise FileNotFoundError(f"Metadata not found: {metadata_path}")
    return faiss.read_index(str(index_path)), pd.read_json(metadata_path)


def retrieve(query, index, metadata, top_k=4, client=None):
    q = embed_texts([query], client=client)
    scores, idx = index.search(q, top_k)

    hits = []
    for score, i in zip(scores[0], idx[0]):
        if i < 0:
            continue
        row = metadata.iloc[int(i)].to_dict()
        row["score"] = float(score)
        hits.append(row)
    return hits


def chat_json(system_prompt, user_prompt, client=None, deployment=None):
    client = client or get_client()
    deployment = deployment or get_chat_deployment()

    response = client.chat.completions.create(
        model=deployment,
        messages=[
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt},
        ],
        temperature=0,
        response_format={"type": "json_object"},
    )

    content = response.choices[0].message.content
    return json.loads(content), response
