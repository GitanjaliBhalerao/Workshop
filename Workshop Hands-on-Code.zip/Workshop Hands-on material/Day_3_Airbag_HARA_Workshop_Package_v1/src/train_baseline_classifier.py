import pandas as pd, pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
df=pd.read_csv("data/D2_airbag_statements.csv")
text_col="statement" if "statement" in df.columns else df.columns[0]
label_col="label" if "label" in df.columns else df.columns[-1]
model=Pipeline([("tfidf",TfidfVectorizer(ngram_range=(1,2))), ("clf",LogisticRegression(max_iter=2000))])
model.fit(df[text_col].astype(str),df[label_col].astype(str))
pickle.dump(model,open("outputs/baseline_classifier.pkl","wb"))
print("Saved outputs/baseline_classifier.pkl")
