import json, pandas as pd

def defect_metrics(gold_ids, predicted_ids):
    gold=set(gold_ids); pred=set(predicted_ids)
    tp=len(gold&pred); fp=len(pred-gold); fn=len(gold-pred)
    precision=tp/(tp+fp) if tp+fp else 0.0; recall=tp/(tp+fn) if tp+fn else 0.0
    return {'tp':tp,'fp':fp,'fn':fn,'precision':precision,'recall':recall}

if __name__=='__main__':
    key=json.load(open('data/D14_answer_key.json'))
    print('Gold defects:',len(key['gold_defects']))
    print('Populate actual reviewer findings and call defect_metrics() to score the run.')
