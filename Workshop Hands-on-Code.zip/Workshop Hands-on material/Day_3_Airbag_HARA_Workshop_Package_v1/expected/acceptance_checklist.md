# Day 3 Acceptance Checklist

## Topic 3.1
- FAISS index exists and has vectors.
- Embeddings generated with Azure OpenAI text-embedding-3-large deployment.
- Retrieval preserves provenance.
- Grounded answer cites evidence.
- Unsupported threshold query abstains.

## Topic 3.2
- Reviewer is independent from generator.
- Deterministic checks execute.
- Model reviewer returns severity and findings.
- Five planted defects are evaluated against the gold set.
- Reviewer does not modify candidate text.

## Topic 3.3
- Strategy matrix completed.
- Rules, classical ML, retrieval, LLM/RAG and human gate are distinguished.

## Topic 3.4
- Generator and reviewer have separate metric blocks.
- Retrieval, citation, coverage, defect catch rate, abstention and latency are measured.
- One controlled improvement rerun is recorded.
