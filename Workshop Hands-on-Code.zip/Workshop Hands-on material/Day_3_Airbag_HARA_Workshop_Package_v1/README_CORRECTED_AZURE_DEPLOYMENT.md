# Day 3 Corrected Workshop Package

Start with **START_HERE_DAY_3.md** for the Day 1/Day 2 dependency instructions.

# Day 3 Corrected Azure Deployment Package

## Standard infrastructure
- Azure OpenAI Chat deployment
- Azure OpenAI `text-embedding-3-large` deployment
- FAISS local vector index
- Python 3.10+
- Jupyter / VS Code

## Critical configuration rule
Azure API calls require the **actual deployment name**. The notebooks no longer fall back to `text-embedding-3-small`, `text-embedding-3-large`, or `gpt-4o`.

Create a file named `azure.env` at the package root:

```text
AZURE_OPENAI_ENDPOINT=https://YOUR-RESOURCE.openai.azure.com/
AZURE_OPENAI_API_KEY=YOUR_API_KEY
AZURE_OPENAI_API_VERSION=YOUR_API_VERSION
AZURE_OPENAI_CHAT_DEPLOYMENT=YOUR_CHAT_DEPLOYMENT_NAME
AZURE_OPENAI_EMBEDDING_DEPLOYMENT=YOUR_TEXT_EMBEDDING_3_LARGE_DEPLOYMENT_NAME
```

The first RAG notebook performs an embedding preflight before building FAISS. If the deployment is wrong, it fails immediately with a configuration/deployment error rather than several cells later.

## Recommended execution order
1. Configure `azure.env`.
2. Open Topic 3.1.
3. Run the configuration cell.
4. Run Azure configuration validation.
5. Run the embedding preflight.
6. Only after preflight succeeds, build/load FAISS.
7. Continue with retrieval and generation.
