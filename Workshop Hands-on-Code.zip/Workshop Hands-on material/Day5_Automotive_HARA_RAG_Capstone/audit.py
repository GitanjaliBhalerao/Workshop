import json
import uuid
from datetime import datetime, timezone
from config import AUDIT_FILE, CASES_DIR

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def create_case(query):
    case_id = "CASE-" + uuid.uuid4().hex[:8].upper()
    case = {"case_id": case_id, "query": query, "created_at": now_iso(), "status": "IN_PROGRESS"}
    CASES_DIR.mkdir(parents=True, exist_ok=True)
    with (CASES_DIR / f"{case_id}.json").open("w", encoding="utf-8") as f:
        json.dump(case, f, indent=2)
    return case

def update_case(case_id, updates):
    path = CASES_DIR / f"{case_id}.json"
    case = {}
    if path.exists():
        with path.open("r", encoding="utf-8") as f:
            case = json.load(f)
    case.update(updates)
    case["updated_at"] = now_iso()
    CASES_DIR.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(case, f, indent=2, default=str)
    return case

def log_workflow(case_id, stage, data):
    AUDIT_FILE.parent.mkdir(parents=True, exist_ok=True)
    record = {"case_id": case_id, "stage": stage, "timestamp": now_iso(), "data": data}
    with AUDIT_FILE.open("a", encoding="utf-8") as f:
        f.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
