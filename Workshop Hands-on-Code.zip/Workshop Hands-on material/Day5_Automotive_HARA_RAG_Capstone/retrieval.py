from indexing import load_index
from config import TOP_K

def retrieve_evidence(query, k=None):
    vectorstore = load_index()
    documents = vectorstore.similarity_search(query, k=(k or TOP_K))
    return [{
        "document_id": doc.metadata.get("document_id", "unknown"),
        "title": doc.metadata.get("title", ""),
        "source": doc.metadata.get("source", "unknown"),
        "status": doc.metadata.get("status", "unknown"),
        "topic": doc.metadata.get("topic", ""),
        "content": doc.page_content,
    } for doc in documents]
