import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from config import validate_azure_config, FAISS_DIR, DATA_DIR

if __name__ == "__main__":
    print("AUTOMOTIVE HARA RAG - ENVIRONMENT CHECK")
    validate_azure_config()
    print("Azure configuration: PASS")
    corpus = DATA_DIR / "hara_corpus.jsonl"
    print(f"Corpus: {'PASS' if corpus.exists() else 'FAIL'}")
    faiss_ok = (FAISS_DIR / "index.faiss").exists() and (FAISS_DIR / "index.pkl").exists()
    print(f"FAISS index: {'PASS' if faiss_ok else 'NOT BUILT'}")
