import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from corpus import load_documents
from indexing import save_index

if __name__ == "__main__":
    print("=" * 60)
    print("AUTOMOTIVE HARA RAG - FAISS INDEX BUILDER")
    print("=" * 60)
    documents = load_documents()
    print(f"Approved documents loaded: {len(documents)}")
    save_index(documents)
    print("\nFAISS index created successfully.")
    print("  artifacts/faiss_index/index.faiss")
    print("  artifacts/faiss_index/index.pkl")
