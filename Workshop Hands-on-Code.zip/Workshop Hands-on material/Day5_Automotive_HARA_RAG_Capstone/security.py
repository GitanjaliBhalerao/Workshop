BLOCKED_PATTERNS = [
    "ignore previous instructions",
    "ignore all previous instructions",
    "bypass reviewer",
    "skip human review",
    "skip the reviewer",
    "approve automatically",
    "publish automatically",
    "bypass human gate",
    "bypass the human gate",
]

def security_gate(query):
    q = query.lower()
    for pattern in BLOCKED_PATTERNS:
        if pattern in q:
            return {"status": "BLOCKED", "reason": f"Security policy violation detected: '{pattern}'."}
    return {"status": "PASS", "reason": "No prohibited instruction detected."}
