import json
from langchain_openai import AzureChatOpenAI
from config import (
    AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_CHAT_DEPLOYMENT, validate_azure_config
)

def get_llm():
    validate_azure_config()
    return AzureChatOpenAI(
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
        api_key=AZURE_OPENAI_API_KEY,
        api_version=AZURE_OPENAI_API_VERSION,
        azure_deployment=AZURE_OPENAI_CHAT_DEPLOYMENT,
        temperature=0,
    )

def generate_candidate(query, evidence):
    if not evidence:
        return {
            "answer": "I cannot answer this from the approved HARA evidence available to the assistant.",
            "evidence_ids": [], "abstain": True,
            "abstain_reason": "No approved evidence was retrieved.",
            "limitations": ["No supporting evidence was retrieved."]
        }

    evidence_text = "\n\n".join(
        f"DOCUMENT ID: {item['document_id']}\nTITLE: {item['title']}\nCONTENT: {item['content']}"
        for item in evidence
    )
    prompt = f"""
You are an Automotive HARA engineering assistant used for training.
Answer the user's question ONLY using the approved evidence below.

USER QUESTION:
{query}

APPROVED EVIDENCE:
{evidence_text}

Rules:
1. Do not invent engineering values or thresholds.
2. Do not invent calibration values.
3. Do not assign or change ASIL.
4. Do not approve safety requirements.
5. If evidence is insufficient, abstain.
6. Identify the evidence IDs used.
7. Return ONLY valid JSON:
{{
  "answer": "string",
  "evidence_ids": ["string"],
  "abstain": true,
  "abstain_reason": "string",
  "limitations": ["string"]
}}
"""
    response = get_llm().invoke(prompt)
    content = response.content
    if isinstance(content, list):
        content = "".join(part.get("text", "") if isinstance(part, dict) else str(part) for part in content)
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        return {
            "answer": "The model returned an invalid structured response.",
            "evidence_ids": [], "abstain": True,
            "abstain_reason": "Candidate output was not valid JSON.",
            "limitations": ["Model output failed structured parsing."]
        }
