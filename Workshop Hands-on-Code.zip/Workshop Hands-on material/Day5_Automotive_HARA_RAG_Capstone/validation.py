from pydantic import BaseModel, Field, ValidationError

class CandidateResponse(BaseModel):
    answer: str = Field(min_length=1)
    evidence_ids: list[str] = Field(default_factory=list)
    abstain: bool = False
    abstain_reason: str = ""
    limitations: list[str] = Field(default_factory=list)

def validate_candidate(candidate):
    try:
        validated = CandidateResponse.model_validate(candidate)
        if validated.abstain and not validated.abstain_reason.strip():
            return {"valid": False, "error": "An abstaining response must include an abstain_reason."}
        return {"valid": True, "data": validated.model_dump()}
    except ValidationError as exc:
        return {"valid": False, "error": str(exc)}
