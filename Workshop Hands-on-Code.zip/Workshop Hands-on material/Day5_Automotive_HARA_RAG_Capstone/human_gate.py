from audit import log_workflow, update_case

VALID_DECISIONS = {"APPROVE", "REJECT"}

def record_human_decision(case_id, decision, reason):
    decision = (decision or "").strip().upper()
    reason = (reason or "").strip()
    if not case_id:
        return {"status": "ERROR", "message": "case_id is required."}
    if decision not in VALID_DECISIONS:
        return {"status": "ERROR", "message": "Decision must be APPROVE or REJECT."}
    if not reason:
        return {"status": "ERROR", "message": "Decision reason cannot be empty."}
    final_status = "PUBLISHED" if decision == "APPROVE" else "REJECTED"
    result = {"case_id": case_id, "decision": decision, "reason": reason, "status": final_status}
    update_case(case_id, result)
    log_workflow(case_id, "HUMAN_DECISION", result)
    return result
