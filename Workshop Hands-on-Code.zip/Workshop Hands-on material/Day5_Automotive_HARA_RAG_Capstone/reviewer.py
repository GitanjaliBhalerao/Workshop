import json
from langchain_openai import AzureChatOpenAI
from config import (
    AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_CHAT_DEPLOYMENT, validate_azure_config
)

def get_reviewer_llm():
    validate_azure_config()
    return AzureChatOpenAI(
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
        api_key=AZURE_OPENAI_API_KEY,
        api_version=AZURE_OPENAI_API_VERSION,
        azure_deployment=AZURE_OPENAI_CHAT_DEPLOYMENT,
        temperature=0,
    )

def independent_review(query, candidate, evidence):
    evidence_text = "\n\n".join(f"{x['document_id']}: {x['content']}" for x in evidence)
    prompt = f"""
Act as an independent reviewer for an automotive HARA RAG assistant.

QUESTION:
{query}

CANDIDATE:
{json.dumps(candidate, ensure_ascii=False)}

APPROVED EVIDENCE:
{evidence_text}

Check evidence grounding, unsupported claims, hallucination, evidence gaps,
abstention appropriateness, and whether the answer attempts a safety approval.

Return ONLY valid JSON:
{{
  "decision": "PASS" or "REVIEW_REQUIRED" or "REJECT",
  "severity": "LOW" or "MEDIUM" or "HIGH",
  "findings": ["string"],
  "unsupported_claims": ["string"],
  "evidence_gaps": ["string"],
  "rationale": "string"
}}
"""
    response = get_reviewer_llm().invoke(prompt)
    content = response.content
    if isinstance(content, list):
        content = "".join(part.get("text", "") if isinstance(part, dict) else str(part) for part in content)
    try:
        return json.loads(content)
    except json.JSONDecodeError:
        return {
            "decision": "REVIEW_REQUIRED", "severity": "HIGH",
            "findings": ["Reviewer output was not valid JSON."],
            "unsupported_claims": [], "evidence_gaps": [],
            "rationale": "Manual review required because reviewer output could not be parsed."
        }
