from langchain_community.vectorstores import FAISS
from langchain_openai import AzureOpenAIEmbeddings
from config import (
    AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_API_KEY, AZURE_OPENAI_API_VERSION,
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT, FAISS_DIR, validate_azure_config
)

def get_embeddings():
    validate_azure_config()
    return AzureOpenAIEmbeddings(
        azure_endpoint=AZURE_OPENAI_ENDPOINT,
        api_key=AZURE_OPENAI_API_KEY,
        api_version=AZURE_OPENAI_API_VERSION,
        azure_deployment=AZURE_OPENAI_EMBEDDING_DEPLOYMENT,
    )

def save_index(documents):
    embeddings = get_embeddings()
    FAISS_DIR.mkdir(parents=True, exist_ok=True)
    vectorstore = FAISS.from_documents(documents, embeddings)
    vectorstore.save_local(str(FAISS_DIR))
    return vectorstore

def load_index():
    index_file = FAISS_DIR / "index.faiss"
    metadata_file = FAISS_DIR / "index.pkl"
    if not index_file.exists() or not metadata_file.exists():
        raise FileNotFoundError(
            "FAISS index not found.\n\n"
            f"Expected folder: {FAISS_DIR}\n"
            "Expected files: index.faiss and index.pkl\n\n"
            "Build it first with: python scripts/build_index.py"
        )
    embeddings = get_embeddings()
    return FAISS.load_local(
        str(FAISS_DIR), embeddings, allow_dangerous_deserialization=True
    )
