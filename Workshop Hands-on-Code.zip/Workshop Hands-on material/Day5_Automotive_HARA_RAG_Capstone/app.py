from flask import Flask, render_template, request, jsonify
from workflow import run_controlled_rag
from human_gate import record_human_decision

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/health")
def health():
    return jsonify({"status": "healthy", "application": "Automotive HARA RAG Assistant"})

@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json(silent=True) or {}
    query = data.get("query", "").strip()
    if not query:
        return jsonify({"status": "ERROR", "message": "Please enter an engineering question."}), 400
    try:
        return jsonify(run_controlled_rag(query))
    except Exception as exc:
        return jsonify({"status": "ERROR", "message": str(exc)}), 500

@app.route("/api/decision", methods=["POST"])
def decision():
    data = request.get_json(silent=True) or {}
    try:
        result = record_human_decision(
            data.get("case_id", ""),
            data.get("decision", ""),
            data.get("reason", "")
        )
        return jsonify(result), (200 if result.get("status") != "ERROR" else 400)
    except Exception as exc:
        return jsonify({"status": "ERROR", "message": str(exc)}), 500

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
