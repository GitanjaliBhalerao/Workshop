import json
from langchain_core.documents import Document
from config import DATA_DIR

CORPUS_FILE = DATA_DIR / "hara_corpus.jsonl"

def load_documents():
    if not CORPUS_FILE.exists():
        raise FileNotFoundError(f"HARA corpus not found: {CORPUS_FILE}")
    documents = []
    with CORPUS_FILE.open("r", encoding="utf-8") as file:
        for line_number, line in enumerate(file, start=1):
            if not line.strip():
                continue
            try:
                record = json.loads(line)
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSON on corpus line {line_number}: {exc}") from exc
            if record.get("status") != "approved":
                continue
            for key in ["id", "content"]:
                if not record.get(key):
                    raise ValueError(f"Corpus line {line_number} missing: {key}")
            documents.append(Document(
                page_content=record["content"],
                metadata={
                    "document_id": record["id"],
                    "title": record.get("title", ""),
                    "source": record.get("source", "HARA"),
                    "status": record.get("status", "approved"),
                    "topic": record.get("topic", ""),
                }
            ))
    if not documents:
        raise ValueError("No approved HARA documents found.")
    return documents
