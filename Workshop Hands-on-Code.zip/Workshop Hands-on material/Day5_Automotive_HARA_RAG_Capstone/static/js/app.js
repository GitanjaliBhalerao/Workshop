let currentCaseId=null;

function applyWorkflow(w){
  document.querySelectorAll("#workflow div").forEach(x=>x.classList.remove("complete","blocked","pending"));
  const map={security:w.security,retrieval:w.retrieval,generation:w.generation,review:w.review,human_gate:w.human_gate,audit:w.audit};
  for(const [key,value] of Object.entries(map)){
    const el=document.querySelector(`[data-step="${key}"]`);
    if(!el) continue;
    if(["PASS","COMPLETE","READY","LOGGED"].includes(value)) el.classList.add("complete");
    else if(value==="BLOCKED") el.classList.add("blocked");
    else if(value==="PENDING") el.classList.add("pending");
  }
}

function esc(v){return String(v).replaceAll("&","&amp;").replaceAll("<","&lt;").replaceAll(">","&gt;").replaceAll('"',"&quot;").replaceAll("'","&#039;")}

function renderEvidence(items){
  const c=document.getElementById("evidence"); c.innerHTML="";
  if(!items.length){c.textContent="No evidence retrieved.";return;}
  items.forEach(x=>{
    const d=document.createElement("div"); d.className="evidence-item";
    d.innerHTML=`<strong>${esc(x.document_id)}</strong> — ${esc(x.title)}<br><small>Source: ${esc(x.source)}</small><p>${esc(x.content)}</p>`;
    c.appendChild(d);
  });
}

async function runQuery(){
  const query=document.getElementById("query").value.trim();
  if(!query){document.getElementById("status").textContent="Please enter a query.";return;}
  document.getElementById("answer").textContent="Running...";
  document.getElementById("review").textContent="Running...";
  document.getElementById("human-section").classList.add("hidden");

  try{
    const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({query})});
    const result=await r.json();
    document.getElementById("status").textContent=result.status||"UNKNOWN";
    currentCaseId=result.case_id||null;
    if(result.workflow) applyWorkflow(result.workflow);

    if(result.status==="BLOCKED"){
      document.getElementById("answer").textContent=result.message;
      document.getElementById("review").textContent="Not executed because security blocked the request.";
      document.getElementById("evidence").textContent="Retrieval was not executed.";
      return;
    }
    if(result.status==="ERROR"||result.status==="VALIDATION_FAILED"){
      document.getElementById("answer").textContent=result.message||"Workflow failed.";
      document.getElementById("review").textContent="Not available.";
      return;
    }

    document.getElementById("answer").textContent=result.candidate?.answer||"No answer returned.";
    document.getElementById("review").textContent=JSON.stringify(result.review||{},null,2);
    renderEvidence(result.evidence||[]);
    if(result.status==="HUMAN_REVIEW_REQUIRED") document.getElementById("human-section").classList.remove("hidden");
  }catch(e){
    document.getElementById("status").textContent="ERROR";
    document.getElementById("answer").textContent=e.toString();
  }
}

async function submitDecision(decision){
  const reason=document.getElementById("reason").value.trim();
  if(!currentCaseId){document.getElementById("decision-result").textContent="No active case.";return;}
  const r=await fetch("/api/decision",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({case_id:currentCaseId,decision,reason})});
  const result=await r.json();
  document.getElementById("decision-result").textContent=JSON.stringify(result,null,2);
  if(result.status!=="ERROR"){
    document.querySelector('[data-step="human_gate"]').classList.remove("pending");
    document.querySelector('[data-step="human_gate"]').classList.add("complete");
    document.querySelector('[data-step="audit"]').classList.add("complete");
  }
}

document.getElementById("ask").addEventListener("click",runQuery);
document.getElementById("approve").addEventListener("click",()=>submitDecision("APPROVE"));
document.getElementById("reject").addEventListener("click",()=>submitDecision("REJECT"));
