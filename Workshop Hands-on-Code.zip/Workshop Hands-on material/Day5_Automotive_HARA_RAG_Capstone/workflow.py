from security import security_gate
from retrieval import retrieve_evidence
from generation import generate_candidate
from validation import validate_candidate
from reviewer import independent_review
from audit import create_case, log_workflow, update_case

def run_controlled_rag(query):
    case = create_case(query)
    case_id = case["case_id"]

    security_result = security_gate(query)
    log_workflow(case_id, "INTAKE_SECURITY", security_result)

    if security_result["status"] == "BLOCKED":
        result = {
            "case_id": case_id, "status": "BLOCKED",
            "workflow": {
                "security": "BLOCKED", "retrieval": "NOT_RUN",
                "generation": "NOT_RUN", "validation": "NOT_RUN",
                "review": "NOT_RUN", "human_gate": "NOT_RUN", "audit": "LOGGED"
            },
            "message": security_result["reason"]
        }
        update_case(case_id, result)
        return result

    evidence = retrieve_evidence(query)
    log_workflow(case_id, "FAISS_RETRIEVAL", {"documents_retrieved": len(evidence)})

    candidate = generate_candidate(query, evidence)
    log_workflow(case_id, "GPT4_GENERATION", candidate)

    validation = validate_candidate(candidate)
    if not validation["valid"]:
        result = {
            "case_id": case_id, "status": "VALIDATION_FAILED",
            "workflow": {
                "security": "PASS", "retrieval": "COMPLETE",
                "generation": "COMPLETE", "validation": "FAILED",
                "review": "NOT_RUN", "human_gate": "NOT_RUN", "audit": "LOGGED"
            },
            "message": validation["error"]
        }
        update_case(case_id, result)
        return result

    validated_candidate = validation["data"]
    log_workflow(case_id, "STRUCTURED_VALIDATION", {"status": "PASS"})

    review = independent_review(query, validated_candidate, evidence)
    log_workflow(case_id, "INDEPENDENT_REVIEW", review)

    result = {
        "case_id": case_id, "status": "HUMAN_REVIEW_REQUIRED",
        "workflow": {
            "security": "PASS", "retrieval": "COMPLETE",
            "generation": "COMPLETE", "validation": "PASS",
            "review": "COMPLETE", "human_gate": "PENDING", "audit": "READY"
        },
        "query": query, "evidence": evidence,
        "candidate": validated_candidate, "review": review
    }
    update_case(case_id, result)
    return result
