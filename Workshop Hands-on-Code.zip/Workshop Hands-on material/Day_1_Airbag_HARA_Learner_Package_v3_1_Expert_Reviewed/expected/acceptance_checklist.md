# Day 1 Learner Acceptance Checklist

## Topic 1.1
- [ ] Dataset schema check passes
- [ ] Minimum class-size check passes
- [ ] Stratified train/test split passes
- [ ] Metrics captured
- [ ] Confusion matrix reviewed
- [ ] Three errors explained
- [ ] Model saved and reloadable

## Topic 1.2
- [ ] Source sufficiency check passes
- [ ] Structured extraction succeeds
- [ ] Pydantic validation passes
- [ ] `item_extract.json` saved
- [ ] Unsupported threshold test completed
- [ ] Boundary/prompt-injection test completed
- [ ] Temperature experiment completed if supported

## Topic 1.3
- [ ] Prompt regression test set has positive/negative/boundary cases
- [ ] Four starter prompts reviewed
- [ ] Versioned v2 prompt created
- [ ] Regression cases executed
- [ ] Evidence and abstention controls documented

## Topic 1.4
- [ ] Scope input sufficiency check passes
- [ ] Human gates reviewed
- [ ] Backlog has representative dependency coverage
- [ ] Dependencies resolve
- [ ] Dependency graph is acyclic
- [ ] Acceptance criteria are testable
- [ ] Formal validator passes
