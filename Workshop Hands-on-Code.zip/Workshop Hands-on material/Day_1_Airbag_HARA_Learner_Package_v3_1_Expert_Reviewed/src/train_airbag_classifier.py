from pathlib import Path
import pandas as pd, joblib
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

DATA = Path("data/D2_airbag_statements.csv")
OUT = Path("outputs")
MIN_SAMPLES_PER_CLASS = 4

df = pd.read_csv(DATA)
required = {"statement_id", "statement", "label"}
missing = required - set(df.columns)
if missing:
    raise ValueError(f"Missing required columns: {sorted(missing)}")

counts = df["label"].value_counts()
print("Dataset shape:", df.shape)
print("\nClass distribution:")
print(counts)

if counts.min() < MIN_SAMPLES_PER_CLASS:
    raise ValueError(
        f"Insufficient data for stratified split. Minimum required per class: "
        f"{MIN_SAMPLES_PER_CLASS}; observed minimum: {counts.min()}."
    )

X_train, X_test, y_train, y_test = train_test_split(
    df["statement"],
    df["label"],
    test_size=0.25,
    random_state=42,
    stratify=df["label"],
)

model = Pipeline([
    ("tfidf", TfidfVectorizer(ngram_range=(1, 2))),
    ("clf", LogisticRegression(max_iter=2000)),
])
model.fit(X_train, y_train)

OUT.mkdir(exist_ok=True)
joblib.dump(model, OUT / "baseline_classifier.pkl")
print(f"\nSaved {OUT / 'baseline_classifier.pkl'}")
print("Training rows:", len(X_train))
print("Test rows:", len(X_test))
