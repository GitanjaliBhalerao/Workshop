import csv, json
from pathlib import Path

scope = json.loads(Path("../templates/scope.json").read_text(encoding="utf-8"))
required_scope = ["project","objective","in_scope","out_of_scope","human_gates","acceptance_principle"]
missing = [x for x in required_scope if x not in scope]
if missing:
    raise SystemExit("Missing scope fields: " + ", ".join(missing))

with open("../templates/backlog.csv", encoding="utf-8") as f:
    rows = list(csv.DictReader(f))

required_cols = ["id","epic","task","dependency","technique","acceptance_criteria","status"]
if not rows:
    raise SystemExit("Backlog is empty.")
missing_cols = [c for c in required_cols if c not in rows[0]]
if missing_cols:
    raise SystemExit("Missing backlog columns: " + ", ".join(missing_cols))

ids = [r["id"] for r in rows]
if len(ids) != len(set(ids)):
    raise SystemExit("Duplicate backlog IDs found.")

id_set = set(ids)
edges = []
for r in rows:
    deps = [x.strip() for x in r["dependency"].split(",") if x.strip()]
    for dep in deps:
        if dep not in id_set:
            raise SystemExit(f"Unresolved dependency: {r['id']} -> {dep}")
        edges.append((dep, r["id"]))

# Cycle detection using Kahn's algorithm; no networkx dependency required.
incoming = {i: 0 for i in id_set}
adj = {i: [] for i in id_set}
for a, b in edges:
    adj[a].append(b)
    incoming[b] += 1

queue = [i for i, n in incoming.items() if n == 0]
visited = []
while queue:
    node = queue.pop(0)
    visited.append(node)
    for nxt in adj[node]:
        incoming[nxt] -= 1
        if incoming[nxt] == 0:
            queue.append(nxt)

if len(visited) != len(id_set):
    raise SystemExit("Dependency cycle detected in backlog.")

print("[PASS] scope.json required fields")
print(f"[PASS] backlog.csv: {len(rows)} records")
print("[PASS] unique IDs")
print("[PASS] dependencies resolve")
print("[PASS] dependency graph is acyclic")
