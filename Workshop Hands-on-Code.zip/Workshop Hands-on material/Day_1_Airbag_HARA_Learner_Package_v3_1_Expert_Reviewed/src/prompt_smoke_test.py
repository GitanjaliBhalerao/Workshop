from pathlib import Path
import os
from dotenv import load_dotenv
from openai import AzureOpenAI
load_dotenv()
required=["AZURE_OPENAI_ENDPOINT","AZURE_OPENAI_API_KEY","AZURE_OPENAI_API_VERSION","AZURE_OPENAI_CHAT_DEPLOYMENT"]
missing=[k for k in required if not os.getenv(k)]
if missing: raise SystemExit("Missing Azure variables: "+", ".join(missing))
client=AzureOpenAI(azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],api_key=os.environ["AZURE_OPENAI_API_KEY"],api_version=os.environ["AZURE_OPENAI_API_VERSION"])
source=Path("data/airbag_item_definition_v1.txt").read_text()
for p in ["prompts/item_extraction_v1.txt","prompts/function_extraction_v1.txt","prompts/malfunction_extraction_v1.txt","prompts/hara_evidence_abstention_v1.txt"]:
    prompt=Path(p).read_text()
    r=client.chat.completions.create(model=os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT"],temperature=0,messages=[{"role":"system","content":prompt},{"role":"user","content":source[:6000]}])
    print("\n---",p,"---\n",(r.choices[0].message.content or "")[:1500])
