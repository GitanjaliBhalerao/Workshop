import pandas as pd, joblib
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix
df=pd.read_csv("data/D2_airbag_statements.csv")
Xtr,Xte,ytr,yte=train_test_split(df.statement,df.label,test_size=.25,random_state=42,stratify=df.label)
model=joblib.load("outputs/baseline_classifier.pkl")
pred=model.predict(Xte)
print(classification_report(yte,pred,zero_division=0))
print("Confusion matrix:")
print(confusion_matrix(yte,pred,labels=sorted(df.label.unique())))
err=pd.DataFrame({"statement":Xte,"actual":yte,"predicted":pred})
print("Errors:")
print(err[err.actual!=err.predicted].to_string(index=False))
