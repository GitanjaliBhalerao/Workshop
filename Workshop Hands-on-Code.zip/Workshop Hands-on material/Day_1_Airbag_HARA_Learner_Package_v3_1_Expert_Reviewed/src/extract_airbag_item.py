import json, os
from pathlib import Path
from dotenv import load_dotenv
from pydantic import BaseModel, Field
from openai import AzureOpenAI
load_dotenv()
class Evidence(BaseModel):
    section:str
    text:str
class ItemExtract(BaseModel):
    item:str
    functions:list[str]=Field(default_factory=list)
    interfaces:list[str]=Field(default_factory=list)
    safety_relevant_statements:list[str]=Field(default_factory=list)
    operating_context:str
    evidence:list[Evidence]=Field(default_factory=list)
required=["AZURE_OPENAI_ENDPOINT","AZURE_OPENAI_API_KEY","AZURE_OPENAI_API_VERSION","AZURE_OPENAI_CHAT_DEPLOYMENT"]
missing=[k for k in required if not os.getenv(k)]
if missing: raise SystemExit("Missing Azure variables: "+", ".join(missing))
client=AzureOpenAI(azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],api_key=os.environ["AZURE_OPENAI_API_KEY"],api_version=os.environ["AZURE_OPENAI_API_VERSION"])
system=Path("prompts/L2_item_extraction_prompt.txt").read_text()
source=Path("data/airbag_item_definition_v1.txt").read_text()
user=f"SOURCE DOCUMENT\n{source}\n\nReturn JSON matching this schema:\n{ItemExtract.model_json_schema()}"
resp=client.chat.completions.create(model=os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT"],temperature=0,
 messages=[{"role":"system","content":system},{"role":"user","content":user}],response_format={"type":"json_object"})
data=json.loads(resp.choices[0].message.content)
validated=ItemExtract.model_validate(data)
Path("outputs").mkdir(exist_ok=True)
Path("outputs/item_extract.json").write_text(validated.model_dump_json(indent=2),encoding="utf-8")
print(validated.model_dump_json(indent=2))
