import importlib, os, sys
from pathlib import Path
REQUIRED=["pandas","numpy","sklearn","joblib","pydantic","dotenv"]
print("=== DAY 1 ENVIRONMENT CHECK ===")
print("Python:",sys.version.split()[0])
failed=[]
for name in REQUIRED:
    try: importlib.import_module(name); print("[PASS]",name)
    except Exception as e: print("[FAIL]",name,e); failed.append(name)
for p in ["data/D2_airbag_statements.csv","data/airbag_item_definition_v1.txt","data/airbag_item_definition_boundary_test.txt"]:
    print("[PASS]" if Path(p).exists() else "[FAIL]",p)
for k in ["AZURE_OPENAI_ENDPOINT","AZURE_OPENAI_API_KEY","AZURE_OPENAI_CHAT_DEPLOYMENT"]:
    print("[SET]" if os.getenv(k) else "[NOT SET]",k)
if failed: raise SystemExit("Resolve package issues before the lab.")
