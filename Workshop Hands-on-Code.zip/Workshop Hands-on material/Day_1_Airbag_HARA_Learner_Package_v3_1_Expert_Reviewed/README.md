# Day 1 Airbag HARA Learner Package — v3 Expert Reviewed

This package has been reviewed as a hands-on GenAI/ML engineering lab and updated for data sufficiency and execution robustness.

## Major corrections
1. Topic 1.1 dataset is now balanced: exactly 5 examples per class across 6 classes (30 records).
2. Topic 1.1 includes an explicit data-sufficiency pre-flight check before stratification.
3. Topic 1.2 includes source-document sufficiency validation.
4. Topic 1.3 includes a dedicated 8-case prompt regression dataset covering positive, negative, boundary, injection, evidence and structure cases.
5. Topic 1.4 contains a larger dependency-aware backlog and built-in cycle detection without requiring networkx.
6. Validation scripts now fail fast on missing columns, duplicate IDs, unresolved dependencies and cycles.
7. Each notebook ends with acceptance criteria, summary of learning, conclusion and recommendations.

## Approved Day 1 schedule remains unchanged
09:00–09:20 Welcome, Objectives & Pre-Work Check
09:20–10:45 Topic 1.1 — AI, ML and GenAI in Plain Terms
10:45–11:00 Break
11:00–12:15 Topic 1.2 — What GenAI Gets Wrong
12:15–13:00 Lunch
13:00–14:30 Topic 1.3 — Writing Prompts That Behave
14:30–14:45 Break
14:45–16:00 Topic 1.4 — Project Scope, Gates and Backlog
16:00–16:15 Day 1 Wrap-up & Manifest Update

## Execution chain
D2_airbag_statements.csv
→ baseline_classifier.pkl
→ item_extract.json
→ prompt regression suite
→ scope.json + backlog.csv
→ accepted Day 1 artifacts

Never commit real credentials. Use `.env` locally and follow organizational secret-management controls.
